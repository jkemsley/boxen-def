# LastPass Puppet Module for Boxen

Install [LastPass](https://lastpass.com/). The Universal Mac OS X installer installs browser extensions for Safari, Firefox, Chrome, and Opera.

## Usage

```puppet
include lastpass
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `rake build` to test it.
